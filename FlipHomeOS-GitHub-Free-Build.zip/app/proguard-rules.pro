# No custom ProGuard rules are required for the v0.1 prototype.
