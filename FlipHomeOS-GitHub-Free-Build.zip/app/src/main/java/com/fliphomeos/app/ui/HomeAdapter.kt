package com.fliphomeos.app.ui

import android.content.pm.PackageManager
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fliphomeos.app.R
import com.fliphomeos.app.databinding.ItemAppBinding
import com.fliphomeos.app.model.AppEntry
import java.util.Collections

class HomeAdapter(
    private val packageManager: PackageManager,
    private val onClick: (AppEntry) -> Unit,
    private val onLongPress: (AppEntry) -> Boolean
) : RecyclerView.Adapter<HomeAdapter.AppViewHolder>() {

    private val items = mutableListOf<AppEntry>()
    private var editing = false

    init {
        setHasStableIds(true)
    }

    fun submitApps(apps: List<AppEntry>) {
        items.clear()
        items.addAll(apps)
        notifyDataSetChanged()
    }

    fun setEditing(value: Boolean) {
        if (editing == value) return
        editing = value
        notifyDataSetChanged()
    }

    fun moveItem(from: Int, to: Int): Boolean {
        if (from !in items.indices || to !in items.indices) return false
        Collections.swap(items, from, to)
        notifyItemMoved(from, to)
        return true
    }

    fun currentPackages(): List<String> = items.map { it.packageName }

    override fun getItemId(position: Int): Long = items[position].packageName.hashCode().toLong()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class AppViewHolder(private val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppEntry) {
            binding.appLabel.text = app.label
            binding.appIcon.setImageDrawable(runCatching {
                packageManager.getApplicationIcon(app.packageName)
            }.getOrNull())

            if (editing) {
                binding.appItemRoot.setBackgroundResource(R.drawable.app_edit_background)
            } else {
                binding.appItemRoot.setBackgroundColor(Color.TRANSPARENT)
            }

            binding.root.setOnClickListener { onClick(app) }
            binding.root.setOnLongClickListener { onLongPress(app) }
        }
    }
}
