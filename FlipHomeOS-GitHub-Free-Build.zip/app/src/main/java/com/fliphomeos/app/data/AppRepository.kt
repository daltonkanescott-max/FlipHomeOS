package com.fliphomeos.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.fliphomeos.app.model.AppEntry

class AppRepository(private val context: Context) {
    private val packageManager: PackageManager = context.packageManager

    fun getLauncherApps(): List<AppEntry> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        return packageManager
            .queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0))
            .asSequence()
            .filter { it.activityInfo?.packageName != context.packageName }
            .mapNotNull { info ->
                val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                val label = info.loadLabel(packageManager)?.toString()?.trim().orEmpty()
                    .ifBlank { packageName }
                AppEntry(packageName, label)
            }
            .distinctBy { it.packageName }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
            .toList()
    }

    fun makeStarterLayout(allApps: List<AppEntry>): List<String> {
        val preferred = listOf(
            "com.sec.android.app.camera",
            "com.samsung.android.dialer",
            "com.google.android.apps.messaging",
            "com.samsung.android.messaging",
            "com.android.chrome",
            "com.google.android.apps.maps",
            "com.spotify.music",
            "com.google.android.youtube"
        )

        val packagesAvailable = allApps.map { it.packageName }.toSet()
        val result = preferred.filter { it in packagesAvailable }.toMutableList()

        allApps.forEach { app ->
            if (result.size < 8 && app.packageName !in result) {
                result += app.packageName
            }
        }
        return result
    }
}
