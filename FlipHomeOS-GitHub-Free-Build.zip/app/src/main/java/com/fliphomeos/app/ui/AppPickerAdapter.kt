package com.fliphomeos.app.ui

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fliphomeos.app.databinding.ItemAppPickerBinding
import com.fliphomeos.app.model.AppEntry
import java.util.Locale

class AppPickerAdapter(
    private val packageManager: PackageManager,
    initiallySelected: Collection<String>
) : RecyclerView.Adapter<AppPickerAdapter.PickerViewHolder>() {

    private val selected = initiallySelected.toMutableSet()
    private var allApps: List<AppEntry> = emptyList()
    private var shownApps: List<AppEntry> = emptyList()

    fun submitApps(apps: List<AppEntry>) {
        allApps = apps
        shownApps = apps
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        val clean = query.trim().lowercase(Locale.ROOT)
        shownApps = if (clean.isBlank()) {
            allApps
        } else {
            allApps.filter {
                it.label.lowercase(Locale.ROOT).contains(clean) ||
                    it.packageName.lowercase(Locale.ROOT).contains(clean)
            }
        }
        notifyDataSetChanged()
    }

    fun selectedPackages(): Set<String> = selected.toSet()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PickerViewHolder {
        val binding = ItemAppPickerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PickerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PickerViewHolder, position: Int) {
        holder.bind(shownApps[position])
    }

    override fun getItemCount(): Int = shownApps.size

    inner class PickerViewHolder(private val binding: ItemAppPickerBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppEntry) {
            binding.pickerLabel.text = app.label
            binding.pickerIcon.setImageDrawable(runCatching {
                packageManager.getApplicationIcon(app.packageName)
            }.getOrNull())

            binding.pickerCheck.setOnCheckedChangeListener(null)
            binding.pickerCheck.isChecked = app.packageName in selected

            fun toggle() {
                if (app.packageName in selected) selected.remove(app.packageName)
                else selected.add(app.packageName)
                binding.pickerCheck.isChecked = app.packageName in selected
            }

            binding.root.setOnClickListener { toggle() }
            binding.pickerCheck.setOnCheckedChangeListener { _, checked ->
                if (checked) selected.add(app.packageName) else selected.remove(app.packageName)
            }
        }
    }
}
