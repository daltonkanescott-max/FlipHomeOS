package com.fliphomeos.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.fliphomeos.app.data.AppRepository
import com.fliphomeos.app.data.HomePreferences
import com.fliphomeos.app.databinding.ActivityAppPickerBinding

class AppPickerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAppPickerBinding
    private lateinit var prefs: HomePreferences
    private lateinit var repository: AppRepository
    private lateinit var adapter: AppPickerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = HomePreferences(this)
        repository = AppRepository(this)
        val allApps = repository.getLauncherApps()

        adapter = AppPickerAdapter(packageManager, prefs.getHomePackages())
        binding.appsList.layoutManager = LinearLayoutManager(this)
        binding.appsList.adapter = adapter
        adapter.submitApps(allApps)

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        binding.cancelButton.setOnClickListener { finish() }
        binding.saveButton.setOnClickListener {
            val chosen = adapter.selectedPackages()
            val oldOrder = prefs.getHomePackages()
            val keptInOrder = oldOrder.filter { it in chosen }
            val newlyAdded = allApps
                .map { it.packageName }
                .filter { it in chosen && it !in keptInOrder }

            prefs.setHomePackages(keptInOrder + newlyAdded)
            setResult(RESULT_OK)
            finish()
        }
    }
}
