package com.fliphomeos.app.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray

class HomePreferences(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getHomePackages(): List<String> {
        val raw = prefs.getString(KEY_HOME_APPS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val value = array.optString(i)
                    if (value.isNotBlank()) add(value)
                }
            }
        }.getOrDefault(emptyList())
    }

    fun setHomePackages(packages: List<String>) {
        val array = JSONArray()
        packages.distinct().forEach(array::put)
        prefs.edit().putString(KEY_HOME_APPS, array.toString()).apply()
    }

    fun getColumns(): Int = prefs.getInt(KEY_COLUMNS, 4).coerceIn(3, 5)

    fun setColumns(columns: Int) {
        prefs.edit().putInt(KEY_COLUMNS, columns.coerceIn(3, 5)).apply()
    }

    fun getWallpaperUri(): Uri? = prefs.getString(KEY_WALLPAPER, null)?.let(Uri::parse)

    fun setWallpaperUri(uri: Uri?) {
        prefs.edit().apply {
            if (uri == null) remove(KEY_WALLPAPER) else putString(KEY_WALLPAPER, uri.toString())
        }.apply()
    }

    fun getWallpaperDim(): Float = prefs.getFloat(KEY_DIM, 0.28f).coerceIn(0f, 0.7f)

    fun setWallpaperDim(value: Float) {
        prefs.edit().putFloat(KEY_DIM, value.coerceIn(0f, 0.7f)).apply()
    }

    companion object {
        private const val PREFS_NAME = "flip_home_prefs"
        private const val KEY_HOME_APPS = "home_apps"
        private const val KEY_COLUMNS = "columns"
        private const val KEY_WALLPAPER = "wallpaper_uri"
        private const val KEY_DIM = "wallpaper_dim"
    }
}
