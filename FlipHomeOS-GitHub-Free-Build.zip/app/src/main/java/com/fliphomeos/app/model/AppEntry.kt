package com.fliphomeos.app.model

data class AppEntry(
    val packageName: String,
    val label: String
)
