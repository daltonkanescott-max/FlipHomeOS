package com.fliphomeos.app.ui

import android.app.AlertDialog
import android.app.KeyguardManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.fliphomeos.app.data.AppRepository
import com.fliphomeos.app.data.HomePreferences
import com.fliphomeos.app.data.WallpaperDecoder
import com.fliphomeos.app.databinding.ActivityMainBinding
import com.fliphomeos.app.model.AppEntry
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: HomePreferences
    private lateinit var repository: AppRepository
    private lateinit var homeAdapter: HomeAdapter
    private lateinit var itemTouchHelper: ItemTouchHelper

    private var editMode = false
    private val handler = Handler(Looper.getMainLooper())

    private val appPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) loadHomeApps()
    }

    private val wallpaperLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.setWallpaperUri(uri)
            applyWallpaper()
        }
    }

    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = HomePreferences(this)
        repository = AppRepository(this)

        homeAdapter = HomeAdapter(
            packageManager = packageManager,
            onClick = { app -> if (!editMode) launchApp(app) },
            onLongPress = {
                if (!editMode) {
                    setEditMode(true)
                    true
                } else {
                    false
                }
            }
        )

        binding.homeGrid.adapter = homeAdapter
        configureGrid()
        configureDragAndDrop()
        configureInsets()
        configureControls()

        binding.rootContainer.setOnLongClickListener {
            setEditMode(true)
            true
        }

        updateClock()
        applyWallpaper()
        loadHomeApps()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(clockRunnable)
        handler.post(clockRunnable)
        loadHomeApps()
    }

    override fun onPause() {
        handler.removeCallbacks(clockRunnable)
        super.onPause()
    }

    private fun configureControls() {
        binding.appsButton.setOnClickListener {
            appPickerLauncher.launch(Intent(this, AppPickerActivity::class.java))
        }
        binding.wallpaperButton.setOnClickListener { showWallpaperMenu() }
        binding.gridButton.setOnClickListener { showGridDialog() }
        binding.doneButton.setOnClickListener { setEditMode(false) }
    }

    private fun configureGrid() {
        binding.homeGrid.layoutManager = GridLayoutManager(this, prefs.getColumns())
    }

    private fun configureDragAndDrop() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT,
            0
        ) {
            override fun isLongPressDragEnabled(): Boolean = editMode

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return homeAdapter.moveItem(viewHolder.bindingAdapterPosition, target.bindingAdapterPosition)
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                prefs.setHomePackages(homeAdapter.currentPackages())
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit
        }

        itemTouchHelper = ItemTouchHelper(callback)
        itemTouchHelper.attachToRecyclerView(binding.homeGrid)
    }

    private fun configureInsets() {
        val density = resources.displayMetrics.density
        val baseSide = (12 * density).toInt()
        val baseTopBottom = (8 * density).toInt()

        ViewCompat.setOnApplyWindowInsetsListener(binding.contentContainer) { view, insets ->
            val cutout = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
            view.setPadding(
                max(baseSide, cutout.left),
                max(baseTopBottom, cutout.top),
                max(baseSide, cutout.right),
                max(baseTopBottom, cutout.bottom)
            )
            insets
        }
        ViewCompat.requestApplyInsets(binding.contentContainer)
    }

    private fun setEditMode(enabled: Boolean) {
        editMode = enabled
        binding.editPanel.visibility = if (enabled) View.VISIBLE else View.GONE
        binding.editBadge.visibility = if (enabled) View.VISIBLE else View.GONE
        homeAdapter.setEditing(enabled)
    }

    private fun loadHomeApps() {
        val allApps = repository.getLauncherApps()
        var packages = prefs.getHomePackages()
        if (packages.isEmpty()) {
            packages = repository.makeStarterLayout(allApps)
            prefs.setHomePackages(packages)
        }

        val byPackage = allApps.associateBy { it.packageName }
        val apps = packages.mapNotNull(byPackage::get)
        homeAdapter.submitApps(apps)
    }

    private fun launchApp(app: AppEntry) {
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (keyguard?.isDeviceLocked == true) {
            Toast.makeText(this, "Unlock the phone before opening apps.", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            Toast.makeText(this, "${app.label} cannot be launched from the cover.", Toast.LENGTH_SHORT).show()
            return
        }

        runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(intent)
        }.onFailure {
            Toast.makeText(this, "Could not open ${app.label}.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateClock() {
        val now = LocalDateTime.now()
        binding.clockText.text = now.format(DateTimeFormatter.ofPattern("h:mm"))
        binding.dateText.text = now.format(DateTimeFormatter.ofPattern("EEEE, MMM d"))
    }

    private fun applyWallpaper() {
        binding.wallpaperDim.alpha = prefs.getWallpaperDim()
        val uri = prefs.getWallpaperUri()

        if (uri == null) {
            binding.wallpaperView.setImageDrawable(null)
            return
        }

        Thread {
            val bitmap: Bitmap? = runCatching {
                WallpaperDecoder.decode(contentResolver, uri)
            }.getOrNull()

            runOnUiThread {
                if (prefs.getWallpaperUri() == uri) {
                    if (bitmap != null) {
                        binding.wallpaperView.setImageBitmap(bitmap)
                    } else {
                        prefs.setWallpaperUri(null)
                        binding.wallpaperView.setImageDrawable(null)
                    }
                }
            }
        }.start()
    }

    private fun showWallpaperMenu() {
        val options = arrayOf("Choose image", "Wallpaper dim", "Remove wallpaper")
        AlertDialog.Builder(this)
            .setTitle("Wallpaper")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> wallpaperLauncher.launch(arrayOf("image/*"))
                    1 -> showDimDialog()
                    2 -> {
                        prefs.setWallpaperUri(null)
                        binding.wallpaperView.setImageDrawable(null)
                    }
                }
            }
            .show()
    }

    private fun showDimDialog() {
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val label = TextView(this)
        val seek = SeekBar(this).apply {
            max = 70
            progress = (prefs.getWallpaperDim() * 100).toInt()
        }

        fun updateLabel(progress: Int) {
            label.text = "Dim: $progress%"
        }
        updateLabel(seek.progress)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLabel(progress)
                binding.wallpaperDim.alpha = progress / 100f
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        container.addView(label)
        container.addView(seek)

        AlertDialog.Builder(this)
            .setTitle("Wallpaper dim")
            .setView(container)
            .setNegativeButton("Cancel") { _, _ ->
                binding.wallpaperDim.alpha = prefs.getWallpaperDim()
            }
            .setPositiveButton("Save") { _, _ ->
                prefs.setWallpaperDim(seek.progress / 100f)
            }
            .show()
    }

    private fun showGridDialog() {
        val choices = arrayOf("3 columns", "4 columns", "5 columns")
        val currentIndex = prefs.getColumns() - 3

        AlertDialog.Builder(this)
            .setTitle("Home grid")
            .setSingleChoiceItems(choices, currentIndex) { dialog, which ->
                prefs.setColumns(which + 3)
                configureGrid()
                dialog.dismiss()
            }
            .show()
    }
}
