package com.fliphomeos.app.model

import java.util.UUID

sealed class HomeItem {
    abstract val id: String

    data class App(
        val packageName: String,
        override val id: String = "app:$packageName:${UUID.randomUUID()}"
    ) : HomeItem()

    data class Folder(
        override val id: String = UUID.randomUUID().toString(),
        var name: String,
        val packages: MutableList<String>
    ) : HomeItem()
}

data class HomePage(
    val id: String = UUID.randomUUID().toString(),
    val items: MutableList<HomeItem> = mutableListOf()
)
