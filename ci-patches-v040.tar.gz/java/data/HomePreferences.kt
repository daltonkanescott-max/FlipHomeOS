package com.fliphomeos.app.data

import android.content.Context
import android.net.Uri
import com.fliphomeos.app.model.HomeItem
import com.fliphomeos.app.model.HomePage
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class HomePreferences(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getPages(): MutableList<HomePage> {
        val raw = prefs.getString(KEY_PAGES, null)
        if (raw.isNullOrBlank()) {
            val legacy = getLegacyHomePackages()
            return if (legacy.isEmpty()) mutableListOf() else mutableListOf(
                HomePage(items = legacy.map { HomeItem.App(it) }.toMutableList())
            )
        }

        return runCatching {
            val pagesArray = JSONArray(raw)
            val pages = mutableListOf<HomePage>()
            for (i in 0 until pagesArray.length()) {
                val pageJson = pagesArray.optJSONObject(i) ?: continue
                val page = HomePage(
                    id = pageJson.optString("id").ifBlank { UUID.randomUUID().toString() },
                    items = mutableListOf()
                )
                val items = pageJson.optJSONArray("items") ?: JSONArray()
                for (j in 0 until items.length()) {
                    val item = items.optJSONObject(j) ?: continue
                    when (item.optString("type")) {
                        "app" -> {
                            val pkg = item.optString("package")
                            if (pkg.isNotBlank()) {
                                page.items += HomeItem.App(
                                    packageName = pkg,
                                    id = item.optString("id").ifBlank { "app:$pkg:${UUID.randomUUID()}" }
                                )
                            }
                        }

                        "folder" -> {
                            val pkgs = mutableListOf<String>()
                            val children = item.optJSONArray("packages") ?: JSONArray()
                            for (k in 0 until children.length()) {
                                children.optString(k).takeIf { it.isNotBlank() }?.let(pkgs::add)
                            }
                            page.items += HomeItem.Folder(
                                id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                                name = item.optString("name").ifBlank { "Folder" },
                                packages = pkgs
                            )
                        }
                    }
                }
                pages += page
            }
            pages
        }.getOrDefault(mutableListOf())
    }

    fun setPages(pages: List<HomePage>) {
        val pagesArray = JSONArray()
        pages.forEach { page ->
            val pageJson = JSONObject()
            pageJson.put("id", page.id)
            val itemsArray = JSONArray()
            page.items.forEach { item ->
                val itemJson = JSONObject()
                itemJson.put("id", item.id)
                when (item) {
                    is HomeItem.App -> {
                        itemJson.put("type", "app")
                        itemJson.put("package", item.packageName)
                    }
                    is HomeItem.Folder -> {
                        itemJson.put("type", "folder")
                        itemJson.put("name", item.name)
                        val children = JSONArray()
                        item.packages.forEach(children::put)
                        itemJson.put("packages", children)
                    }
                }
                itemsArray.put(itemJson)
            }
            pageJson.put("items", itemsArray)
            pagesArray.put(pageJson)
        }
        prefs.edit().putString(KEY_PAGES, pagesArray.toString()).apply()
    }

    fun getHomePackages(): List<String> = getPages().firstOrNull()?.items
        ?.filterIsInstance<HomeItem.App>()
        ?.map { it.packageName }
        .orEmpty()

    fun setHomePackages(packages: List<String>) {
        val pages = getPages().ifEmpty { mutableListOf(HomePage()) }
        val first = pages.first()
        val folders = first.items.filterIsInstance<HomeItem.Folder>()
        first.items.clear()
        first.items.addAll(packages.distinct().map { HomeItem.App(it) })
        first.items.addAll(folders)
        setPages(pages)
    }

    fun getColumns(): Int = prefs.getInt(KEY_COLUMNS, 4).coerceIn(3, 5)
    fun setColumns(columns: Int) = prefs.edit().putInt(KEY_COLUMNS, columns.coerceIn(3, 5)).apply()

    fun getIconScale(): Float = prefs.getFloat(KEY_ICON_SCALE, 1.0f).coerceIn(0.78f, 1.22f)
    fun setIconScale(scale: Float) = prefs.edit().putFloat(KEY_ICON_SCALE, scale.coerceIn(0.78f, 1.22f)).apply()

    fun getShowLabels(): Boolean = prefs.getBoolean(KEY_SHOW_LABELS, true)
    fun setShowLabels(show: Boolean) = prefs.edit().putBoolean(KEY_SHOW_LABELS, show).apply()

    fun getClockStyle(): String = prefs.getString(KEY_CLOCK_STYLE, CLOCK_LARGE) ?: CLOCK_LARGE
    fun setClockStyle(style: String) = prefs.edit().putString(KEY_CLOCK_STYLE, style).apply()

    fun getWallpaperUri(): Uri? = prefs.getString(KEY_WALLPAPER, null)?.let(Uri::parse)
    fun setWallpaperUri(uri: Uri?) {
        prefs.edit().apply {
            if (uri == null) remove(KEY_WALLPAPER) else putString(KEY_WALLPAPER, uri.toString())
        }.apply()
    }

    fun getWallpaperDim(): Float = prefs.getFloat(KEY_DIM, 0.28f).coerceIn(0f, 0.7f)
    fun setWallpaperDim(value: Float) = prefs.edit().putFloat(KEY_DIM, value.coerceIn(0f, 0.7f)).apply()

    private fun getLegacyHomePackages(): List<String> {
        val raw = prefs.getString(KEY_HOME_APPS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    array.optString(i).takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }.getOrDefault(emptyList())
    }

    companion object {
        const val CLOCK_LARGE = "large"
        const val CLOCK_COMPACT = "compact"
        const val CLOCK_HIDDEN = "hidden"

        private const val PREFS_NAME = "flip_home_prefs"
        private const val KEY_PAGES = "home_pages_v2"
        private const val KEY_HOME_APPS = "home_apps"
        private const val KEY_COLUMNS = "columns"
        private const val KEY_ICON_SCALE = "icon_scale"
        private const val KEY_SHOW_LABELS = "show_labels"
        private const val KEY_CLOCK_STYLE = "clock_style"
        private const val KEY_WALLPAPER = "wallpaper_uri"
        private const val KEY_DIM = "wallpaper_dim"
    }
}
