package com.fliphomeos.app.ui

import android.app.KeyguardManager
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.fliphomeos.app.data.AppRepository
import com.fliphomeos.app.databinding.ActivityAppDrawerBinding
import com.fliphomeos.app.model.AppEntry
import com.fliphomeos.app.service.CoverDisplayLauncher

class AppDrawerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAppDrawerBinding
    private lateinit var adapter: AppDrawerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repository = AppRepository(this)
        adapter = AppDrawerAdapter(packageManager, ::launchApp)
        binding.appsList.layoutManager = LinearLayoutManager(this)
        binding.appsList.adapter = adapter
        adapter.submitApps(repository.getLauncherApps())

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        binding.closeButton.setOnClickListener { finish() }
    }

    private fun launchApp(app: AppEntry) {
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (keyguard?.isDeviceLocked == true) {
            Toast.makeText(this, "Unlock the phone before opening apps.", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            Toast.makeText(this, "${app.label} cannot be launched from the cover.", Toast.LENGTH_SHORT).show()
            return
        }

        runCatching {
            CoverDisplayLauncher.launch(this, intent)
        }.onFailure {
            Toast.makeText(this, "Could not open ${app.label}.", Toast.LENGTH_SHORT).show()
        }
    }
}
