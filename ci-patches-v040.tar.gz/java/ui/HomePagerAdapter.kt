package com.fliphomeos.app.ui

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.fliphomeos.app.databinding.ItemHomePageBinding
import com.fliphomeos.app.model.HomeItem
import com.fliphomeos.app.model.HomePage

class HomePagerAdapter(
    private val packageManager: PackageManager,
    private val onAppClick: (HomeItem.App) -> Unit,
    private val onFolderClick: (HomeItem.Folder) -> Unit,
    private val onLongPress: (pageIndex: Int, item: HomeItem, position: Int) -> Boolean,
    private val onOrderChanged: (pageIndex: Int, items: MutableList<HomeItem>) -> Unit
) : RecyclerView.Adapter<HomePagerAdapter.PageViewHolder>() {

    private val pages = mutableListOf<HomePage>()
    private var columns = 4
    private var editing = false
    private var iconScale = 1f
    private var showLabels = true

    init {
        setHasStableIds(true)
    }

    fun submitPages(newPages: List<HomePage>) {
        pages.clear()
        pages.addAll(newPages)
        notifyDataSetChanged()
    }

    fun setColumns(value: Int) {
        columns = value
        notifyDataSetChanged()
    }

    fun setEditing(value: Boolean) {
        editing = value
        notifyDataSetChanged()
    }

    fun setStyle(scale: Float, labels: Boolean) {
        iconScale = scale
        showLabels = labels
        notifyDataSetChanged()
    }

    override fun getItemId(position: Int): Long = pages[position].id.hashCode().toLong()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val binding = ItemHomePageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        holder.bind(position, pages[position])
    }

    override fun getItemCount(): Int = pages.size

    inner class PageViewHolder(private val binding: ItemHomePageBinding) : RecyclerView.ViewHolder(binding.root) {
        private var boundPageIndex = 0
        private val itemAdapter = HomeItemAdapter(
            packageManager = packageManager,
            onAppClick = onAppClick,
            onFolderClick = onFolderClick,
            onLongPress = { item, position -> onLongPress(boundPageIndex, item, position) }
        )

        init {
            binding.pageGrid.adapter = itemAdapter
            ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT,
                0
            ) {
                override fun isLongPressDragEnabled(): Boolean = editing

                override fun onMove(
                    recyclerView: RecyclerView,
                    viewHolder: RecyclerView.ViewHolder,
                    target: RecyclerView.ViewHolder
                ): Boolean {
                    return itemAdapter.moveItem(
                        viewHolder.bindingAdapterPosition,
                        target.bindingAdapterPosition
                    )
                }

                override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                    super.clearView(recyclerView, viewHolder)
                    onOrderChanged(boundPageIndex, itemAdapter.currentItems())
                }

                override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit
            }).attachToRecyclerView(binding.pageGrid)
        }

        fun bind(pageIndex: Int, page: HomePage) {
            boundPageIndex = pageIndex
            val layout = binding.pageGrid.layoutManager as? GridLayoutManager
            if (layout == null) {
                binding.pageGrid.layoutManager = GridLayoutManager(binding.root.context, columns)
            } else {
                layout.spanCount = columns
            }
            itemAdapter.setEditing(editing)
            itemAdapter.setStyle(iconScale, showLabels)
            itemAdapter.submitItems(page.items)
        }
    }
}
