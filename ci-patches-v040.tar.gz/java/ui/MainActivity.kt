package com.fliphomeos.app.ui

import android.app.AlertDialog
import android.app.KeyguardManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.viewpager2.widget.ViewPager2
import com.fliphomeos.app.data.AppRepository
import com.fliphomeos.app.data.HomePreferences
import com.fliphomeos.app.data.WallpaperDecoder
import com.fliphomeos.app.databinding.ActivityMainBinding
import com.fliphomeos.app.model.AppEntry
import com.fliphomeos.app.model.HomeItem
import com.fliphomeos.app.model.HomePage
import com.fliphomeos.app.service.CoverDisplayLauncher
import com.fliphomeos.app.service.TakeoverSetup
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: HomePreferences
    private lateinit var repository: AppRepository
    private lateinit var pagerAdapter: HomePagerAdapter

    private var pages: MutableList<HomePage> = mutableListOf()
    private var editMode = false
    private var currentPageIndex = 0
    private val handler = Handler(Looper.getMainLooper())

    private val appPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) loadHomePages()
    }

    private val wallpaperLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.setWallpaperUri(uri)
            applyWallpaper()
        }
    }

    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = HomePreferences(this)
        repository = AppRepository(this)

        pagerAdapter = HomePagerAdapter(
            packageManager = packageManager,
            onAppClick = { item -> if (!editMode) launchPackage(item.packageName) },
            onFolderClick = { folder -> openFolder(folder) },
            onLongPress = ::handleItemLongPress,
            onOrderChanged = { pageIndex, items ->
                pages.getOrNull(pageIndex)?.let { page ->
                    page.items.clear()
                    page.items.addAll(items)
                    persistPages()
                }
            }
        )

        binding.homePager.adapter = pagerAdapter
        binding.homePager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        binding.homePager.offscreenPageLimit = 1
        binding.homePager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                currentPageIndex = position
                updatePageIndicator()
            }
        })

        configureInsets()
        configureControls()

        binding.rootContainer.setOnLongClickListener {
            setEditMode(true)
            true
        }

        updateClock()
        applyClockStyle()
        applyWallpaper()
        loadHomePages()
        handler.postDelayed({ TakeoverSetup.promptIfNeeded(this) }, 500L)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(clockRunnable)
        handler.post(clockRunnable)
        loadHomePages()
    }

    override fun onPause() {
        handler.removeCallbacks(clockRunnable)
        super.onPause()
    }

    private fun configureControls() {
        binding.drawerButton.setOnClickListener {
            runCatching {
                CoverDisplayLauncher.launch(this, Intent(this, AppDrawerActivity::class.java))
            }
        }

        binding.appsButton.setOnClickListener {
            val intent = Intent(this, AppPickerActivity::class.java)
                .putExtra(AppPickerActivity.EXTRA_PAGE_INDEX, currentPageIndex)
            appPickerLauncher.launch(intent)
        }
        binding.folderButton.setOnClickListener { showCreateFolderDialog() }
        binding.styleButton.setOnClickListener { showStyleMenu() }
        binding.pageButton.setOnClickListener { showPageMenu() }
        binding.wallpaperButton.setOnClickListener { showWallpaperMenu() }
        binding.doneButton.setOnClickListener { setEditMode(false) }
    }

    private fun configureInsets() {
        val density = resources.displayMetrics.density
        val baseSide = (10 * density).toInt()
        val baseTopBottom = (7 * density).toInt()

        ViewCompat.setOnApplyWindowInsetsListener(binding.contentContainer) { view, insets ->
            val cutout = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
            view.setPadding(
                max(baseSide, cutout.left),
                max(baseTopBottom, cutout.top),
                max(baseSide, cutout.right),
                max(baseTopBottom, cutout.bottom)
            )
            insets
        }
        ViewCompat.requestApplyInsets(binding.contentContainer)
    }

    private fun setEditMode(enabled: Boolean) {
        editMode = enabled
        binding.editPanel.visibility = if (enabled) View.VISIBLE else View.GONE
        binding.editBadge.visibility = if (enabled) View.VISIBLE else View.GONE
        pagerAdapter.setEditing(enabled)
    }

    private fun loadHomePages() {
        val allApps = repository.getLauncherApps()
        val installed = allApps.map { it.packageName }.toSet()
        var loaded = prefs.getPages()

        if (loaded.isEmpty()) {
            val starter = repository.makeStarterLayout(allApps)
            loaded = mutableListOf(HomePage(items = starter.map { HomeItem.App(it) }.toMutableList()))
            prefs.setPages(loaded)
        }

        loaded.forEach { page ->
            val cleaned = page.items.mapNotNull { item ->
                when (item) {
                    is HomeItem.App -> item.takeIf { it.packageName in installed }
                    is HomeItem.Folder -> {
                        item.packages.retainAll(installed)
                        item.takeIf { it.packages.isNotEmpty() }
                    }
                }
            }
            page.items.clear()
            page.items.addAll(cleaned)
        }

        if (loaded.isEmpty()) loaded += HomePage()
        pages = loaded
        persistPages()

        pagerAdapter.setColumns(prefs.getColumns())
        pagerAdapter.setStyle(prefs.getIconScale(), prefs.getShowLabels())
        pagerAdapter.setEditing(editMode)
        pagerAdapter.submitPages(pages)

        currentPageIndex = currentPageIndex.coerceIn(0, pages.lastIndex)
        binding.homePager.setCurrentItem(currentPageIndex, false)
        updatePageIndicator()
        applyClockStyle()
    }

    private fun persistPages() {
        prefs.setPages(pages)
    }

    private fun launchPackage(packageName: String) {
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (keyguard?.isDeviceLocked == true) {
            Toast.makeText(this, "Unlock the phone before opening apps.", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) {
            Toast.makeText(this, "This app cannot be launched from the cover.", Toast.LENGTH_SHORT).show()
            return
        }

        runCatching {
            CoverDisplayLauncher.launch(this, intent)
        }.onFailure {
            Toast.makeText(this, "Could not open ${labelFor(packageName)}.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFolder(folder: HomeItem.Folder) {
        if (editMode) {
            showItemActions(currentPageIndex, folder)
            return
        }

        val validPackages = folder.packages.filter {
            packageManager.getLaunchIntentForPackage(it) != null
        }
        if (validPackages.isEmpty()) {
            Toast.makeText(this, "This folder is empty.", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle(folder.name)
            .setItems(validPackages.map(::labelFor).toTypedArray()) { _, which ->
                launchPackage(validPackages[which])
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun handleItemLongPress(pageIndex: Int, item: HomeItem, position: Int): Boolean {
        if (!editMode) setEditMode(true)
        showItemActions(pageIndex, item)
        return true
    }

    private fun showItemActions(pageIndex: Int, item: HomeItem) {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        if (item is HomeItem.Folder) {
            labels += "Open folder"
            actions += { openFolderWhileEditing(item) }
            labels += "Rename folder"
            actions += { renameFolder(item) }
            labels += "Unpack folder"
            actions += { unpackFolder(pageIndex, item) }
        }

        if (pageIndex > 0) {
            labels += "Move to previous page"
            actions += { moveItemToPage(pageIndex, pageIndex - 1, item) }
        }
        if (pageIndex < pages.lastIndex) {
            labels += "Move to next page"
            actions += { moveItemToPage(pageIndex, pageIndex + 1, item) }
        }

        labels += if (item is HomeItem.Folder) "Remove folder" else "Remove from page"
        actions += { removeItem(pageIndex, item) }

        AlertDialog.Builder(this)
            .setTitle(if (item is HomeItem.Folder) item.name else labelFor((item as HomeItem.App).packageName))
            .setItems(labels.toTypedArray()) { _, which -> actions[which].invoke() }
            .show()
    }

    private fun openFolderWhileEditing(folder: HomeItem.Folder) {
        val valid = folder.packages.filter { packageManager.getLaunchIntentForPackage(it) != null }
        AlertDialog.Builder(this)
            .setTitle(folder.name)
            .setItems(valid.map(::labelFor).toTypedArray(), null)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun renameFolder(folder: HomeItem.Folder) {
        val input = EditText(this).apply {
            setText(folder.name)
            setSelection(text.length)
            isSingleLine = true
        }
        AlertDialog.Builder(this)
            .setTitle("Rename folder")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                folder.name = input.text.toString().trim().ifBlank { "Folder" }
                persistAndRefresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun unpackFolder(pageIndex: Int, folder: HomeItem.Folder) {
        val page = pages.getOrNull(pageIndex) ?: return
        val index = page.items.indexOfFirst { it.id == folder.id }
        if (index < 0) return
        page.items.removeAt(index)
        page.items.addAll(index, folder.packages.map { HomeItem.App(it) })
        persistAndRefresh()
    }

    private fun removeItem(pageIndex: Int, item: HomeItem) {
        pages.getOrNull(pageIndex)?.items?.removeAll { it.id == item.id }
        persistAndRefresh()
    }

    private fun moveItemToPage(from: Int, to: Int, item: HomeItem) {
        val source = pages.getOrNull(from) ?: return
        val target = pages.getOrNull(to) ?: return
        source.items.removeAll { it.id == item.id }
        target.items.add(item)
        currentPageIndex = to
        persistAndRefresh()
        binding.homePager.setCurrentItem(to, true)
    }

    private fun showCreateFolderDialog() {
        val page = pages.getOrNull(currentPageIndex) ?: return
        val directApps = page.items.filterIsInstance<HomeItem.App>()
        if (directApps.size < 2) {
            Toast.makeText(this, "Add at least two apps to this page first.", Toast.LENGTH_SHORT).show()
            return
        }

        val checked = BooleanArray(directApps.size)
        AlertDialog.Builder(this)
            .setTitle("Choose apps for folder")
            .setMultiChoiceItems(directApps.map { labelFor(it.packageName) }.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Next") { _, _ ->
                val selected = directApps.filterIndexed { index, _ -> checked[index] }
                if (selected.size < 2) {
                    Toast.makeText(this, "Choose at least two apps.", Toast.LENGTH_SHORT).show()
                } else {
                    promptFolderName(selected)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptFolderName(selected: List<HomeItem.App>) {
        val input = EditText(this).apply {
            hint = "Folder name"
            isSingleLine = true
        }
        AlertDialog.Builder(this)
            .setTitle("New folder")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val page = pages[currentPageIndex]
                val selectedIds = selected.map { it.id }.toSet()
                val firstIndex = page.items.indexOfFirst { it.id in selectedIds }.coerceAtLeast(0)
                page.items.removeAll { it.id in selectedIds }
                page.items.add(
                    firstIndex.coerceAtMost(page.items.size),
                    HomeItem.Folder(
                        name = input.text.toString().trim().ifBlank { "Folder" },
                        packages = selected.map { it.packageName }.toMutableList()
                    )
                )
                persistAndRefresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPageMenu() {
        val options = if (pages.size > 1) {
            arrayOf("Add page after this one", "Remove current page")
        } else {
            arrayOf("Add page after this one")
        }

        AlertDialog.Builder(this)
            .setTitle("Home pages")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> addPage()
                    1 -> removeCurrentPage()
                }
            }
            .show()
    }

    private fun addPage() {
        val insertAt = (currentPageIndex + 1).coerceAtMost(pages.size)
        pages.add(insertAt, HomePage())
        currentPageIndex = insertAt
        persistAndRefresh()
        binding.homePager.setCurrentItem(insertAt, true)
    }

    private fun removeCurrentPage() {
        if (pages.size <= 1) return
        val page = pages[currentPageIndex]
        AlertDialog.Builder(this)
            .setTitle("Remove page?")
            .setMessage(if (page.items.isEmpty()) "Remove this empty page?" else "Its icons and folders will move to the nearest page.")
            .setPositiveButton("Remove") { _, _ ->
                val targetIndex = if (currentPageIndex > 0) currentPageIndex - 1 else 1
                if (page.items.isNotEmpty()) pages[targetIndex].items.addAll(page.items)
                pages.removeAt(currentPageIndex)
                currentPageIndex = currentPageIndex.coerceAtMost(pages.lastIndex)
                persistAndRefresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showStyleMenu() {
        val options = arrayOf(
            "Grid (${prefs.getColumns()} columns)",
            "Icon size",
            "App labels (${if (prefs.getShowLabels()) "On" else "Off"})",
            "Clock style"
        )
        AlertDialog.Builder(this)
            .setTitle("Home style")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showGridDialog()
                    1 -> showIconSizeDialog()
                    2 -> {
                        prefs.setShowLabels(!prefs.getShowLabels())
                        pagerAdapter.setStyle(prefs.getIconScale(), prefs.getShowLabels())
                    }
                    3 -> showClockStyleDialog()
                }
            }
            .show()
    }

    private fun showGridDialog() {
        val choices = arrayOf("3 columns", "4 columns", "5 columns")
        val selected = prefs.getColumns() - 3
        AlertDialog.Builder(this)
            .setTitle("Grid density")
            .setSingleChoiceItems(choices, selected) { dialog, which ->
                prefs.setColumns(which + 3)
                pagerAdapter.setColumns(prefs.getColumns())
                dialog.dismiss()
            }
            .show()
    }

    private fun showIconSizeDialog() {
        val choices = arrayOf("Small", "Medium", "Large")
        val current = when {
            prefs.getIconScale() < 0.9f -> 0
            prefs.getIconScale() > 1.1f -> 2
            else -> 1
        }
        AlertDialog.Builder(this)
            .setTitle("Icon size")
            .setSingleChoiceItems(choices, current) { dialog, which ->
                prefs.setIconScale(listOf(0.82f, 1.0f, 1.2f)[which])
                pagerAdapter.setStyle(prefs.getIconScale(), prefs.getShowLabels())
                dialog.dismiss()
            }
            .show()
    }

    private fun showClockStyleDialog() {
        val choices = arrayOf("Large", "Compact", "Hidden")
        val current = when (prefs.getClockStyle()) {
            HomePreferences.CLOCK_COMPACT -> 1
            HomePreferences.CLOCK_HIDDEN -> 2
            else -> 0
        }
        AlertDialog.Builder(this)
            .setTitle("Clock style")
            .setSingleChoiceItems(choices, current) { dialog, which ->
                val style = listOf(
                    HomePreferences.CLOCK_LARGE,
                    HomePreferences.CLOCK_COMPACT,
                    HomePreferences.CLOCK_HIDDEN
                )[which]
                prefs.setClockStyle(style)
                applyClockStyle()
                dialog.dismiss()
            }
            .show()
    }

    private fun applyClockStyle() {
        when (prefs.getClockStyle()) {
            HomePreferences.CLOCK_HIDDEN -> {
                binding.clockContainer.visibility = View.GONE
            }
            HomePreferences.CLOCK_COMPACT -> {
                binding.clockContainer.visibility = View.VISIBLE
                binding.clockText.textSize = 18f
                binding.dateText.textSize = 9f
            }
            else -> {
                binding.clockContainer.visibility = View.VISIBLE
                binding.clockText.textSize = 25f
                binding.dateText.textSize = 11f
            }
        }
    }

    private fun updatePageIndicator() {
        if (pages.size <= 1) {
            binding.pageIndicator.visibility = View.INVISIBLE
            return
        }
        binding.pageIndicator.visibility = View.VISIBLE
        binding.pageIndicator.text = buildString {
            pages.indices.forEach { index ->
                if (index > 0) append(' ')
                append(if (index == currentPageIndex) '●' else '○')
            }
        }
    }

    private fun updateClock() {
        val now = LocalDateTime.now()
        binding.clockText.text = now.format(DateTimeFormatter.ofPattern("h:mm"))
        binding.dateText.text = now.format(DateTimeFormatter.ofPattern("EEEE, MMM d"))
    }

    private fun applyWallpaper() {
        binding.wallpaperDim.alpha = prefs.getWallpaperDim()
        val uri = prefs.getWallpaperUri()
        if (uri == null) {
            binding.wallpaperView.setImageDrawable(null)
            return
        }

        Thread {
            val bitmap: Bitmap? = runCatching {
                WallpaperDecoder.decode(contentResolver, uri)
            }.getOrNull()
            runOnUiThread {
                if (prefs.getWallpaperUri() == uri) {
                    if (bitmap != null) binding.wallpaperView.setImageBitmap(bitmap)
                    else {
                        prefs.setWallpaperUri(null)
                        binding.wallpaperView.setImageDrawable(null)
                    }
                }
            }
        }.start()
    }

    private fun showWallpaperMenu() {
        val options = arrayOf("Choose image", "Wallpaper dim", "Remove wallpaper")
        AlertDialog.Builder(this)
            .setTitle("Wallpaper")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> wallpaperLauncher.launch(arrayOf("image/*"))
                    1 -> showDimDialog()
                    2 -> {
                        prefs.setWallpaperUri(null)
                        binding.wallpaperView.setImageDrawable(null)
                    }
                }
            }
            .show()
    }

    private fun showDimDialog() {
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val label = TextView(this)
        val seek = SeekBar(this).apply {
            max = 70
            progress = (prefs.getWallpaperDim() * 100).toInt()
        }

        fun updateLabel(progress: Int) {
            label.text = "Dim: $progress%"
        }
        updateLabel(seek.progress)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLabel(progress)
                binding.wallpaperDim.alpha = progress / 100f
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        container.addView(label)
        container.addView(seek)

        AlertDialog.Builder(this)
            .setTitle("Wallpaper dim")
            .setView(container)
            .setPositiveButton("Save") { _, _ -> prefs.setWallpaperDim(seek.progress / 100f) }
            .setNegativeButton("Cancel") { _, _ -> binding.wallpaperDim.alpha = prefs.getWallpaperDim() }
            .show()
    }

    private fun persistAndRefresh() {
        persistPages()
        pagerAdapter.submitPages(pages)
        pagerAdapter.setColumns(prefs.getColumns())
        pagerAdapter.setStyle(prefs.getIconScale(), prefs.getShowLabels())
        pagerAdapter.setEditing(editMode)
        currentPageIndex = currentPageIndex.coerceIn(0, pages.lastIndex)
        binding.homePager.setCurrentItem(currentPageIndex, false)
        updatePageIndicator()
    }

    private fun labelFor(packageName: String): String {
        return runCatching {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(packageName.substringAfterLast('.'))
    }
}
