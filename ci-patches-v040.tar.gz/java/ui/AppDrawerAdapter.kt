package com.fliphomeos.app.ui

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fliphomeos.app.databinding.ItemAppPickerBinding
import com.fliphomeos.app.model.AppEntry
import java.util.Locale

class AppDrawerAdapter(
    private val packageManager: PackageManager,
    private val onClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppDrawerAdapter.DrawerViewHolder>() {

    private var allApps: List<AppEntry> = emptyList()
    private var shownApps: List<AppEntry> = emptyList()

    fun submitApps(apps: List<AppEntry>) {
        allApps = apps
        shownApps = apps
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        val clean = query.trim().lowercase(Locale.ROOT)
        shownApps = if (clean.isBlank()) allApps else allApps.filter {
            it.label.lowercase(Locale.ROOT).contains(clean) ||
                it.packageName.lowercase(Locale.ROOT).contains(clean)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DrawerViewHolder {
        val binding = ItemAppPickerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DrawerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DrawerViewHolder, position: Int) {
        holder.bind(shownApps[position])
    }

    override fun getItemCount(): Int = shownApps.size

    inner class DrawerViewHolder(private val binding: ItemAppPickerBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppEntry) {
            binding.pickerLabel.text = app.label
            binding.pickerIcon.setImageDrawable(runCatching {
                packageManager.getApplicationIcon(app.packageName)
            }.getOrNull())
            binding.pickerCheck.visibility = android.view.View.GONE
            binding.root.setOnClickListener { onClick(app) }
        }
    }
}
