package com.fliphomeos.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.fliphomeos.app.data.AppRepository
import com.fliphomeos.app.data.HomePreferences
import com.fliphomeos.app.databinding.ActivityAppPickerBinding
import com.fliphomeos.app.model.HomeItem
import com.fliphomeos.app.model.HomePage

class AppPickerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAppPickerBinding
    private lateinit var prefs: HomePreferences
    private lateinit var repository: AppRepository
    private lateinit var adapter: AppPickerAdapter
    private var pageIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = HomePreferences(this)
        repository = AppRepository(this)
        pageIndex = intent.getIntExtra(EXTRA_PAGE_INDEX, 0)

        val allApps = repository.getLauncherApps()
        val pages = prefs.getPages().ifEmpty { mutableListOf(HomePage()) }
        pageIndex = pageIndex.coerceIn(0, pages.lastIndex)
        val selectedOnPage = pages[pageIndex].items
            .filterIsInstance<HomeItem.App>()
            .map { it.packageName }

        adapter = AppPickerAdapter(packageManager, selectedOnPage)
        binding.appsList.layoutManager = LinearLayoutManager(this)
        binding.appsList.adapter = adapter
        adapter.submitApps(allApps)

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        binding.cancelButton.setOnClickListener { finish() }
        binding.saveButton.setOnClickListener {
            val chosen = adapter.selectedPackages()
            val currentPage = pages[pageIndex]
            val existingDirect = currentPage.items.filterIsInstance<HomeItem.App>()
            val folders = currentPage.items.filterIsInstance<HomeItem.Folder>()

            val kept = existingDirect.filter { it.packageName in chosen }
            val keptPackages = kept.map { it.packageName }.toSet()
            val added = allApps
                .map { it.packageName }
                .filter { it in chosen && it !in keptPackages }
                .map { HomeItem.App(it) }

            currentPage.items.clear()
            currentPage.items.addAll(kept)
            currentPage.items.addAll(added)
            currentPage.items.addAll(folders)
            prefs.setPages(pages)

            setResult(RESULT_OK)
            finish()
        }
    }

    companion object {
        const val EXTRA_PAGE_INDEX = "page_index"
    }
}
