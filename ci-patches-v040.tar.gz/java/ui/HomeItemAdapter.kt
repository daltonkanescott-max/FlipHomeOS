package com.fliphomeos.app.ui

import android.content.pm.PackageManager
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.fliphomeos.app.R
import com.fliphomeos.app.databinding.ItemAppBinding
import com.fliphomeos.app.databinding.ItemFolderBinding
import com.fliphomeos.app.model.HomeItem
import java.util.Collections

class HomeItemAdapter(
    private val packageManager: PackageManager,
    private val onAppClick: (HomeItem.App) -> Unit,
    private val onFolderClick: (HomeItem.Folder) -> Unit,
    private val onLongPress: (HomeItem, Int) -> Boolean
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<HomeItem>()
    private var editing = false
    private var iconScale = 1f
    private var showLabels = true

    init {
        setHasStableIds(true)
    }

    fun submitItems(newItems: List<HomeItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun currentItems(): MutableList<HomeItem> = items.toMutableList()

    fun moveItem(from: Int, to: Int): Boolean {
        if (from !in items.indices || to !in items.indices) return false
        Collections.swap(items, from, to)
        notifyItemMoved(from, to)
        return true
    }

    fun setEditing(value: Boolean) {
        if (editing == value) return
        editing = value
        notifyDataSetChanged()
    }

    fun setStyle(scale: Float, labels: Boolean) {
        iconScale = scale
        showLabels = labels
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (items[position]) {
        is HomeItem.App -> TYPE_APP
        is HomeItem.Folder -> TYPE_FOLDER
    }

    override fun getItemId(position: Int): Long = items[position].id.hashCode().toLong()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_FOLDER -> FolderViewHolder(
                ItemFolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
            else -> AppViewHolder(
                ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is AppViewHolder -> holder.bind(items[position] as HomeItem.App)
            is FolderViewHolder -> holder.bind(items[position] as HomeItem.Folder)
        }
    }

    override fun getItemCount(): Int = items.size

    private fun appLabel(packageName: String): String {
        return runCatching {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(packageName.substringAfterLast('.'))
    }

    private fun applyIconSize(view: View, baseDp: Int) {
        val density = view.resources.displayMetrics.density
        val size = (baseDp * iconScale * density).toInt()
        view.layoutParams = view.layoutParams.apply {
            width = size
            height = size
        }
    }

    inner class AppViewHolder(private val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: HomeItem.App) {
            binding.appLabel.text = appLabel(item.packageName)
            binding.appLabel.visibility = if (showLabels) View.VISIBLE else View.GONE
            binding.appIcon.setImageDrawable(runCatching {
                packageManager.getApplicationIcon(item.packageName)
            }.getOrNull())
            applyIconSize(binding.appIcon, 46)

            if (editing) binding.appItemRoot.setBackgroundResource(R.drawable.app_edit_background)
            else binding.appItemRoot.setBackgroundColor(Color.TRANSPARENT)

            binding.root.setOnClickListener { onAppClick(item) }
            binding.root.setOnLongClickListener { onLongPress(item, bindingAdapterPosition) }
        }
    }

    inner class FolderViewHolder(private val binding: ItemFolderBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: HomeItem.Folder) {
            binding.folderLabel.text = item.name
            binding.folderLabel.visibility = if (showLabels) View.VISIBLE else View.GONE
            applyIconSize(binding.folderPreview, 46)

            val icons = listOf(
                binding.folderIcon1,
                binding.folderIcon2,
                binding.folderIcon3,
                binding.folderIcon4
            )
            icons.forEachIndexed { index, image ->
                val pkg = item.packages.getOrNull(index)
                if (pkg == null) {
                    image.visibility = View.INVISIBLE
                    image.setImageDrawable(null)
                } else {
                    image.visibility = View.VISIBLE
                    image.scaleType = ImageView.ScaleType.FIT_CENTER
                    image.setImageDrawable(runCatching {
                        packageManager.getApplicationIcon(pkg)
                    }.getOrNull())
                }
            }

            if (editing) binding.folderItemRoot.setBackgroundResource(R.drawable.app_edit_background)
            else binding.folderItemRoot.setBackgroundColor(Color.TRANSPARENT)

            binding.root.setOnClickListener { onFolderClick(item) }
            binding.root.setOnLongClickListener { onLongPress(item, bindingAdapterPosition) }
        }
    }

    companion object {
        private const val TYPE_APP = 0
        private const val TYPE_FOLDER = 1
    }
}
